//
//  Animating_StrokesApp.swift
//  Animating Strokes
//
//  Created by Stephen DeStefano on 10/5/22.
//

import SwiftUI

@main
struct Animating_StrokesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
