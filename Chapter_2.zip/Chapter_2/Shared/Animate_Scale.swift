//
//  Animate_Scale.swift
//  Chapter_2
//
//  Created by Stephen DeStefano on 4/1/22.
//

import SwiftUI

struct Animate_Scale: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

///In the first example I'm creating a simple green circle, and by using the scale effect modifier, I'm passing in our animating variable. When the state changes to true, the circle scales down to one 10th its size, and when false, it goes back to its original size.
///And using the animation modifier again, with the default timing curve, this is an ease in and out curve, meaning it starts the animation slowly, and then ramps up to its top speed, and then finishes by eases out slowly again.
///The second example is doing the same thing, only I'm using a system image to show you that you can also scale images, either system images or images that you brought into the asset catalogue and are using in the code.
///This particular image is from the SF symbols app, if you don't have this app yet, I highly recommend it, download it free at the developer portal. In it, Apple has given us thousands of images that we can use right in our code. And what’s new in the latest release is that the images now can render multicolor, we just have to set the rendering mode to dot original, so the image gets shown as it is in SF Symbols, instead of just black or white.
///And finally, in the third part example of animating scaling, we use the anchor method, this will scale the view by the given amount in both the horizontal and vertical directions, relative to an anchor point. i used .bottomTrailing as the anchor point so when we press the button, the heart scales down to the bottom, and to the trailing edge, the right side. And we can choose from several different anchor points:
struct AnimateScale: View {
    @State private var scaleCircle = false
    @State private var scaleBug = false
    @State private var scaleFromAnchor = true
    var body: some View {
        VStack () {
            //MARK: - ANIMATE THE SCALE OF A CIRCLE SHAPE
            VStack {
                Text("SCALE SHAPE").font(.title).bold()
                Circle()
                    .frame(width: 150)
                    .foregroundColor(.green)
                    .scaleEffect(scaleCircle ? 0.1 : 1)
                    .animation(.default, value: scaleCircle)
                Button("Scale Shape") {
                    scaleCircle.toggle()
                }
            }.font(.title2)
            Divider().background(Color.black)
            //MARK: - ANIMATE THE SCALE OF A SYSTEM IMAGE
            VStack{
                Text("SCALE IMAGE").font(.title).bold()
                Image(systemName: "ladybug.fill")
                    .renderingMode(.original) //allows multicolor for SF Symbols
                    .resizable()
                    .frame(width: 150, height: 150, alignment: .center)
                    .scaleEffect(scaleBug ? 0.1 : 1)
                    .animation(.default, value: scaleBug)
                    .padding(10)
                Button("Scale Image") {
                    scaleBug.toggle()
                }
            }.font(.title2)
            Divider().background(Color.black)
            //MARK: - ANIMATE THE SCALE FROM AN ANCHOR POINT
            VStack{
                Text("SCALE FROM ANCHOR ").font(.title).bold()
                Image(systemName: "heart.fill")
                    .renderingMode(.original) //allows multicolor for SF Symbols
                    .resizable()
                    .frame(width: 150, height: 125, alignment: .center)
                    .scaleEffect(scaleFromAnchor ? 1 : 0.2, anchor: .bottomTrailing)
                    .animation(.default, value: scaleFromAnchor)
                    .padding(10)
                Button("Scale from Anchor") {
                    scaleFromAnchor.toggle()
                }
            }.font(.title2)
        }
    }
}

struct Animate_Scale_Previews: PreviewProvider {
    static var previews: some View {
        Animate_Scale()
        AnimateScale()
    }
}
