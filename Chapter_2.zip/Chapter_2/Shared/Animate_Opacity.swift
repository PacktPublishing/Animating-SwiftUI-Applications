//
//  Animate_Opacity.swift
//  Chapter_2
//
//  Created by Stephen DeStefano on 4/1/22.
//

import SwiftUI

struct Animate_Opacity: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

///Animating the opacity of a view - And an example  of demonstrating a unique component of opacity in SwiftUI.
///When we apply the opacity modifier to a view that already had its opacity transformed, the modifier will multiply the overall effect.
///For example, the yellow and red circles have their opacity set at 50%, and both are overlapping each other. The top red circle allows some of the bottom yellow circle to show through, thus multiplying the opacity effect so that area is a little darker, and at the same time mingling the two colors so it creates orange.
struct AnimateOpacity: View {
    @State private var appear = false
    var body: some View {
//MARK: - ANIMATE OPACITY
        VStack{
            Text("Appear/Disappear")
                .font(.title).bold()
            Circle()
                .foregroundColor(.purple)
                .opacity(appear ? 1 : 0)
                .animation(.easeIn, value: appear)
                .frame(height: 175)
            Button("Animate") {
                appear.toggle()
            }.font(.title2)
            //MARK: - OVERLAPPING OPACITY
            VStack{
                Text("Overlapping Opacity").bold()
                    .font(.title)
                Circle()
                    .foregroundColor(.yellow)
                    .frame(height: 100)
                    .opacity(0.5)
                Circle()
                    .foregroundColor(.red)
                    .frame(height: 100)
                    .opacity(0.5)
                    .padding(-60)
            }.padding(60)
        }
    }
}

struct Animate_Opacity_Previews: PreviewProvider {
    static var previews: some View {
        Animate_Opacity()
        AnimateOpacity()
    }
}
