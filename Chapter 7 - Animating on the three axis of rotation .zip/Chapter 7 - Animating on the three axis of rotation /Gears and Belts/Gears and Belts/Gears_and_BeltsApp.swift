//
//  Gears_and_BeltsApp.swift
//  Gears and Belts
//
//  Created by Stephen DeStefano on 1/21/22.
//

import SwiftUI

@main
struct Gears_and_BeltsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
