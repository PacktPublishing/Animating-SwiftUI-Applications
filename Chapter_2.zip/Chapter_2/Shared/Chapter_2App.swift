//
//  Chapter_2App.swift
//  Shared
//
//  Created by Stephen DeStefano on 4/1/22.
//

import SwiftUI

@main
struct Chapter_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
