//
//  Animate_Stroke_Trim_CornerRadius.swift
//  Chapter_2
//
//  Created by Stephen DeStefano on 4/1/22.
//

import SwiftUI

struct Animate_Stroke_Trim_CornerRadius: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

///Looking at the first example we have a simple rectangle and then inside the stroke modifier, I pass the animate stroke variable in as an argument to the line width parameter, so when it becomes true, we change the stroke to 25 points, otherwise it will be 1 point. Again, using the default timing curve inside the animation modifier, and when we run this the stroke is smoothly modified from 10 to fat, and back again.
///In the second example we are using the trim property this time, and it takes two parameters, from and to…from means what part of the circle do we want to start trimming from, and the to parameter means where do we want to end the trimming. Here it’s set to zero, which means let's start with a whole circle, and trim off as much as is stored in the circleTrim variable. Looking inside the button code, we're storing inside the circleTrim variable one of two values, either .25, or 1… So, when animateTrim toggles to true, the code is saying, trim off 75% of the circle and leave 25%, or if false, leave 100% of the circle or 1.
///And just to highlight the parameters again on the trim modifier, if we change the 0 value to 0.5, and run the code, where are you now start the trimming at half of the circle… So, it actually looks like that we're animating on or painting on a smile, and then removing the smile.
///And in the final example we're looking at animating the corner radius of a rectangle. The animateCornerRadius property gets checked for a true or false value, if it is false, it gets a value of 75 placed into it. 75 will make this size rectangle into a perfectly round circle. And when toggled back to true, the circle animates into a rectangle by having its corner radius changed to zero.
struct AnimateStrokeTrimCornerRadius: View {
    @State private var animateStroke = false
    @State private var animateTrim = false
    @State private var animateCornerRadius = false
    @State private var circleTrim: CGFloat = 1.0
    var body: some View {
        VStack(spacing: -10) {
            //MARK: - ANIMATE THE STROKE OF THE ROUNDED RECT
            VStack{
                Text("ANIMATE STROKE").font(.title).bold()
                RoundedRectangle(cornerRadius: 30)
                    .stroke(Color.purple, style: StrokeStyle(lineWidth: animateStroke ? 25 : 1))
                    .frame(width: 100, height: 100)
                    .animation(.default, value: animateStroke)
                Button("Animate Stroke") {
                    animateStroke.toggle()
                }
            }.font(.title2)
                .padding(.bottom, 20)
            Divider().background(Color.black)
            //MARK: - ANIMATE THE TRIM MODIFIER OF A CIRCLE
            VStack {
                Text("ANIMATE TRIM").font(.title).bold()
                    .padding(.top, 10)
                Circle()
                    .trim(from: 0, to: circleTrim)
                    .stroke(Color.red, style: StrokeStyle(lineWidth: 30, lineCap: CGLineCap.round))
                    .frame(height: 150)
                    .rotationEffect(.degrees(180))
                    .animation(.default, value: animateTrim)
                    .padding(.bottom, 20)
                Button("Animate Trim") {
                    animateTrim.toggle()
                    circleTrim = animateTrim ? 0.25 : 1
                }
            }.font(.title2)
                .padding(25)
            Divider().background(Color.black)
             
            //MARK: - ANIMATE THE CORNER RADIUS
            VStack{
                Text("ANIMATE CORNER RADIUS").font(.title).bold()
                    .padding(.top, 30)
                Rectangle()
                    .foregroundColor(.green)
                    .frame(width: 150, height: 150)
                .cornerRadius(animateCornerRadius ? 0 : 75)
                .animation(.default, value: animateCornerRadius)
                .padding(.bottom, 20)
                Button("Animate Corner Radius") {
                    animateCornerRadius.toggle()
                }
            }.font(.title2)
        }
    }
}

struct Animate_Stroke_Trim_CornerRadius_Previews: PreviewProvider {
    static var previews: some View {
        Animate_Stroke_Trim_CornerRadius()
        AnimateStrokeTrimCornerRadius()
    }
}
