//
//  Record_PlayerApp.swift
//  Shared
//
//  Created by Stephen DeStefano on 5/14/22.
//

import SwiftUI

@main
struct Record_PlayerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
