
import SwiftUI

struct ContentView: View {
    @State private var selectedImage: String = "ornament"
    @State private var shiftColors = false
    let backgroundColor = Color(.black)
    
    var body: some View {
        VStack {
            ZStack {
                backgroundColor
                    //.edgesIgnoringSafeArea(.all)
                    .scaleEffect(1.4)
                
                Image(selectedImage).resizable().padding(20).frame(width: 400, height: 400)
                    .hueRotation(.degrees(shiftColors ? 360 * 2: 0))
                    .animation(Animation.easeInOut(duration: 10).repeatForever(autoreverses: true))
                    .onAppear() {
                        shiftColors.toggle()
                }
            }
            ImagePickerView(selectedImage: $selectedImage)
                .frame(width: 350, height: 200)
        }.background(backgroundColor)
        .edgesIgnoringSafeArea(.bottom)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
