//
//  Chapter2App.swift
//  Shared
//
//  Created by Stephen DeStefano on 4/26/22.
//

import SwiftUI

@main
struct Chapter2App: App {
    var body: some Scene {
        WindowGroup {
            Corner_Radius_Example()
        }
    }
}
