//
//  Chapter_8App.swift
//  Chapter 8
//
//  Created by Stephen DeStefano on 9/10/22.
//

import SwiftUI

@main
struct Chapter_8App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
