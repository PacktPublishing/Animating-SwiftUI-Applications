//  Chapter_1App.swift
//  Created by Stephen DeStefano

import SwiftUI

@main
struct Chapter_1App: App {
    var body: some Scene {
        WindowGroup {
            ComputedProperty()
        }
    }
}
