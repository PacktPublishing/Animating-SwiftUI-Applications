//
//  Hue_Rotation_Example_1App.swift
//  Hue Rotation Example 1
//
//  Created by Stephen DeStefano on 10/29/20.
//

import SwiftUI

@main
struct Hue_Rotation_Example_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
