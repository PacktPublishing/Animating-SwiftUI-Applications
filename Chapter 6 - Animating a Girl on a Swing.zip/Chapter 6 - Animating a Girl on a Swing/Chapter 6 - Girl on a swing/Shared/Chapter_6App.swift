//
//  Chapter_6App.swift
//  Shared
//
//  Created by Stephen DeStefano on 7/15/22.
//

import SwiftUI

@main
struct Chapter_6App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
